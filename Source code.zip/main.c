#include <gccore.h>
#include <wiiuse/wpad.h>
#include <ogc/lwp_watchdog.h>

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <limits.h>

static int g_cols = 80;
static int g_rows = 30;

static bool g_dark_mode = true;
static u32  g_best_ms   = UINT_MAX;

static void console_goto(int row, int col)
{
    printf("\x1b[%d;%dH", row, col);
}

static void clear_screen_keep_theme(void)
{
    printf("\x1b[2J");
    printf("\x1b[H");
    fflush(stdout);
}

static void apply_theme(void)
{
    printf("\x1b[0m");

    if (g_dark_mode)
    {
        printf("\x1b[37m"); // white text
        printf("\x1b[40m"); // black background
    }
    else
    {
        printf("\x1b[30m"); // black text
        printf("\x1b[47m"); // white background
    }

    clear_screen_keep_theme();
}

static void draw_centered(const char *text)
{
    clear_screen_keep_theme();

    int len = strlen(text);
    int row = g_rows / 2;
    int col = (g_cols - len) / 2 + 1;

    console_goto(row, col);
    printf("%s", text);

    if (g_best_ms != UINT_MAX)
    {
        char best[64];
        snprintf(best, sizeof(best), "Best: %u ms", g_best_ms);

        int best_row = g_rows - 2;
        int best_col = (g_cols - strlen(best)) / 2 + 1;

        console_goto(best_row, best_col);
        printf("%s", best);
    }

    fflush(stdout);
}

static void handle_global_toggles(u32 down)
{
    if (down & WPAD_BUTTON_1)
    {
        g_dark_mode = !g_dark_mode;
        apply_theme();
    }
}

// ----------------------------------------
// Main
// ----------------------------------------

int main(int argc, char **argv)
{
    VIDEO_Init();
    WPAD_Init();

    GXRModeObj *rmode = VIDEO_GetPreferredMode(NULL);
    void *xfb = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));

    console_init(xfb, 0, 0, rmode->fbWidth, rmode->xfbHeight,
                 rmode->fbWidth * VI_DISPLAY_PIX_SZ);

    VIDEO_Configure(rmode);
    VIDEO_SetNextFramebuffer(xfb);
    VIDEO_SetBlack(FALSE);
    VIDEO_Flush();
    VIDEO_WaitVSync();
    if (rmode->viTVMode & VI_NON_INTERLACE) VIDEO_WaitVSync();

    g_cols = rmode->fbWidth / 8;
    g_rows = rmode->xfbHeight / 16;

    srand((unsigned)gettime());
    apply_theme();

    // Title Screen
    draw_centered("ReactMii");

    while (1)
    {
        WPAD_ScanPads();
        u32 down = WPAD_ButtonsDown(0);

        handle_global_toggles(down);

        if (down & WPAD_BUTTON_HOME) return 0;
        if (down & WPAD_BUTTON_A) break;

        VIDEO_WaitVSync();
    }

    // Main Loop
    while (1)
    {
        u32 delay_ms = 2000 + (rand() % 3001);

        draw_centered("...");

        bool too_early = false;
        u64 start = gettime();

        while (ticks_to_millisecs(gettime() - start) < delay_ms)
        {
            WPAD_ScanPads();
            u32 down = WPAD_ButtonsDown(0);

            if (down & WPAD_BUTTON_HOME) return 0;

            if (down & WPAD_BUTTON_A)
            {
                too_early = true;
                break;
            }

            VIDEO_WaitVSync();
        }

        if (too_early)
        {
            draw_centered("TOO EARLY!");

            while (1)
            {
                WPAD_ScanPads();
                u32 down = WPAD_ButtonsDown(0);

                handle_global_toggles(down);

                if (down & WPAD_BUTTON_HOME) return 0;
                if (down & WPAD_BUTTON_B) break;

                VIDEO_WaitVSync();
            }

            continue;
        }

        draw_centered("GO!");
        u64 go_time = gettime();

        while (1)
        {
            WPAD_ScanPads();
            u32 down = WPAD_ButtonsDown(0);

            handle_global_toggles(down);

            if (down & WPAD_BUTTON_HOME) return 0;

            if (down & WPAD_BUTTON_A)
            {
                u32 reaction_ms =
                    ticks_to_millisecs(gettime() - go_time);

                if (reaction_ms < g_best_ms)
                    g_best_ms = reaction_ms;

                char buf[32];
                snprintf(buf, sizeof(buf), "%u ms", reaction_ms);
                draw_centered(buf);
                break;
            }

            VIDEO_WaitVSync();
        }

        while (1)
        {
            WPAD_ScanPads();
            u32 down = WPAD_ButtonsDown(0);

            handle_global_toggles(down);

            if (down & WPAD_BUTTON_HOME) return 0;
            if (down & WPAD_BUTTON_B) break;

            VIDEO_WaitVSync();
        }
    }

    return 0;
}
